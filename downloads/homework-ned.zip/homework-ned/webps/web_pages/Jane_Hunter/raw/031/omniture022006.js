var s_account="aolinstore,aolsvc";  /*  use devaolinstore for QA and DEV environments */
