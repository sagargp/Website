function FlashBack(id) {
	if (id = S_prop25 ){
		s_linkType=S_linkType;
		s_linkName=S_linkName;
		s_prop23=S_prop23;
		s_prop24=S_prop24;
		s_prop25=S_prop25;
		s_lnk=s_co(GraphicLink);
		s_gs(AsppReportSuiteID);
		window.open(GraphicLink);
	}
	else {window.open(GraphicLink);}
}

function trackingLogic(S_linkType,S_linkName,S_prop23,S_prop24,S_prop25,GraphicLink,AsppReportSuiteID) {
	if (id = S_prop25 ){
		s_linkType=S_linkType;
		s_linkName=S_linkName;
		s_prop23=S_prop23;
		s_prop24=S_prop24;
		s_prop25=S_prop25;
		s_lnk=s_co(GraphicLink);
		s_gs(AsppReportSuiteID);
		window.open(GraphicLink);
	}
	else {
		window.open(GraphicLink);
	}
}